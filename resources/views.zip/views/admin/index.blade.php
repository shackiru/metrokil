<x-admin-template>
    
</x-admin-template>
