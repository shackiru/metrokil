<div class="fixed bottom-0 right-0 p-6 z-10">
    <a href="https://api.whatsapp.com/send/?phone=6281998405395&text=Halo!,+Saya+tertarik+untuk+menyewa+jasa+Metrokil!&type=phone_number&app_absent=0"
        target="_blank">
        <button type="button" class="rounded-full p-3 bg-[#25d366]">
            <img src="{{ asset('icons/socials/ic_baseline-whatsapp.svg') }}" width="35" alt="">
        </button>
    </a>
</div>
